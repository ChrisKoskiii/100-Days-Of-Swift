import UIKit

//Challenge 1

//extension String {
//  mutating func add(prefix: String) {
//    self = prefix + self
//  }
//}
//
//var extensionTest = "pet"
//extensionTest.add(prefix: "car")
//print(extensionTest)

//Challenge 2

//extension String {
//  var isNumeric: Bool {
//    return rangeOfCharacter(from: CharacterSet.decimalDigits) != nil
//  }
//}
//
//var stuff = "This is a sentance with numbers at the end; 34, 45 75"
//stuff.isNumeric
//
//var moreStuff = "asdfiou hes esouf hso"
//moreStuff.isNumeric

//Challenge 3

extension String {
  var lines: [SubSequence] { split(whereSeparator: \.isNewline) }
}

var testString = "this\nis\na\ntest"
testString.lines


